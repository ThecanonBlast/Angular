import { Component } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent {
  display: string = '';
  
  pressBoton(value: string) {
    this.display += value;
  }
  
  calcular() {
    try{
    let expression = this.display;
    this.display = eval(expression);
    }catch (error) {
      this.display = 'Error';
    }
  }
  

}


