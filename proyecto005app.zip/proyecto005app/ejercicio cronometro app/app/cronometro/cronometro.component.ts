import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';


@Component({
  selector: 'app-cronometro',
  templateUrl: './cronometro.component.html',
  styleUrls: ['./cronometro.component.css']
})
export class CronometroComponent {
  segundo=0;
  minuto = 0;
  hora = 0;
  @Input() inicio : number=0;
  @Input() inicio2 : number=0;
  @Input() inicio3 : number=0;
  @Output() multiplo10 = new EventEmitter();
  constructor(){}
 
  ngOnInit(){
    this.segundo = this.inicio;
    setInterval(() => {
      this.segundo++;
      if(this.segundo % 60 == 0){
        this.multiplo10.emit(this.segundo);
        this.multiplo10.emit(this.minuto++);
        this.multiplo10.emit(this.segundo=0);
        if(this.minuto %60 == 0){
          this.multiplo10.emit(this.hora++);
          this.multiplo10.emit(this.minuto=0);
          if(this.hora %24 == 0){
            this.multiplo10.emit(this.hora=0);
          }
        }
      }
      if(this.segundo % 10 == 0)
      this.multiplo10.emit(this.segundo);
    },1000);


   
 
  }
}